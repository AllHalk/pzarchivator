from setuptools import setup

setup(
    name='pzarchivator',
    version='0.1',
    description='Wrapper for PeaZip Command Line',
    packages=['peazip_wrapper'],
    install_requires=[],
)
